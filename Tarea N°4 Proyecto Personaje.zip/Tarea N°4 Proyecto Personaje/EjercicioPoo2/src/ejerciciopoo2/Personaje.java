package ejerciciopoo2;

public class Personaje {

    // Atributos
    private int cantMaxPuntosVida;
    private int cantActualPuntosVida;
    private String nombre;
    private Arma armaa;

    // Constructor
    public Personaje() {
    }

    // Getters
    public int getCantMaxPuntosVida() {
        return cantMaxPuntosVida;
    }

    public int getCantActualPuntosVida() {
        return cantActualPuntosVida;
    }

    public String getNombre() {
        return nombre;
    }

    public Arma getArmaa() {
        return armaa;
    }

    // Setters
    public void setCantMaxPuntosVida(int cantMaxPuntosVida) {
        this.cantMaxPuntosVida = cantMaxPuntosVida;
    }

    public void setCantActualPuntosVida(int cantActualPuntosVida) {
        this.cantActualPuntosVida = cantActualPuntosVida;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setArmaa(Arma armaa) {
        this.armaa = armaa;
    }
}
