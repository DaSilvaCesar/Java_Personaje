package ejerciciopoo2;

public class Arma {
    // Atributos
    private int danioMax;
    private int danioMin;
    private String nombreArma;

    // Constructor con parámetros
    public Arma(int danioMax, int danioMin, String nombreArma) {
        this.danioMax = danioMax;
        this.danioMin = danioMin;
        this.nombreArma = nombreArma;
    }

    // Métodos
    // Getters
    public int getDanioMax() {
        return danioMax;
    }

    public int getDanioMin() {
        return danioMin;
    }

    public String getNombreArma() {
        return nombreArma;
    }

    // Setters
    public void setDanioMax(int danioMax) {
        this.danioMax = danioMax;
    }

    public void setDanioMin(int danioMin) {
        this.danioMin = danioMin;
    }

    public void setNombreArma(String nombreArma) {
        this.nombreArma = nombreArma;
    }
}

