package ejerciciopoo2;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Utilizo un solo Scanner .
        Scanner scanner = new Scanner(System.in);

        // Instancia del objeto Arma
        Arma[] armita = new Arma[3];
        armita[0] = new Arma(1000, 500, "El Hacha Berserker - Tajadera Mortal " +
                "Death Cleaver");
        armita[1] = new Arma(1500, 300, "El Arco de Guardian - Enviudador " +
                "Widowmaker");
        armita[2] = new Arma(3000, 2000, "El Cuchillo Alado - Alcaudón Guerrero " +
                "Warshrike");

        // Instancia del objeto Personaje
        Personaje per1 = new Personaje();

        // Leer datos del personaje
        System.out.println("Ingrese nombre del personaje: ");
        per1.setNombre(scanner.nextLine());

        System.out.println("---------------------------------------------");

        System.out.println("Ingrese cantidad máxima de puntos de HP: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Por favor, ingrese un número válido:");
            scanner.next();
        }
        per1.setCantMaxPuntosVida(scanner.nextInt());

        System.out.println("---------------------------------------------");

        System.out.println("Ingrese cantidad actual de HP : ");
        while (!scanner.hasNextInt()) {
            System.out.println("Por favor, ingrese un número válido:");
            scanner.next();
        }
        per1.setCantActualPuntosVida(scanner.nextInt());

        System.out.println("Elija el arma a Equipar: ");
        for (int i = 0; i < armita.length; i++) {
            System.out.println((i + 1) + " - " + armita[i].getNombreArma());
        }

        int armaSeleccionada = 0;
        while (armaSeleccionada < 1 || armaSeleccionada > armita.length) {
            while (!scanner.hasNextInt()) {
                System.out.println("Por favor, ingrese un número válido:");
                scanner.next();
            }
            armaSeleccionada = scanner.nextInt();
            if (armaSeleccionada < 1 || armaSeleccionada > armita.length) {
                System.out.println("Selección inválida. Por favor, elija un número entre 1 y " + armita.length + ":");
            }
        }

        per1.setArmaa(armita[armaSeleccionada - 1]);

        // Mostrar detalles del personaje
        System.out.println("---------------------------------------------");
        System.out.println("Nombre del personaje: " + per1.getNombre());
        System.out.println("Cantidad Máxima de puntos de HP: " + per1.getCantMaxPuntosVida());
        System.out.println("Cantidad actual de HP: " + per1.getCantActualPuntosVida());
        System.out.println("Arma elegida: " + per1.getArmaa().getNombreArma());
        System.out.println("Daño máximo: " + per1.getArmaa().getDanioMax());
        System.out.println("Daño mínimo: " + per1.getArmaa().getDanioMin());

        // Cerrar el scanner
        scanner.close();
    }
}

